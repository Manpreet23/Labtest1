package com.example.labtest1

import android.app.Activity
import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.RecyclerView
import com.example.labtest1.db.StudentEntity
import com.example.labtest1.viewmodel.DetailViewModel
import kotlinx.android.synthetic.main.activity_edit_page.*
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.*

class EditPage : AppCompatActivity(), View.OnClickListener {

    lateinit var viewModel: DetailViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        setContentView(R.layout.activity_edit_page)




        initViews()
        check()
     iv_back.setOnClickListener(this)
        btn_submit.setOnClickListener(this)
    }

    private fun check() {
        val name = intent.getStringExtra("name")
        val age = intent.getIntExtra("age",0)
        val tuition = intent.getDoubleExtra("tuition",0.0)
        val date = intent.getStringExtra("date")

        et_name.setText(name)
        et_age.setText(age.toString())
        et_tuition.setText(tuition.toString())
        et_date.setText(date)

    }

    private fun initViews() {
        val iv_back : ImageView = findViewById(R.id.iv_back)
        val et_name : EditText = findViewById(R.id.et_name)
        val et_age : EditText = findViewById(R.id.et_age)
        val et_tuition : EditText = findViewById(R.id.et_tuition)
        val et_date : EditText = findViewById(R.id.et_date)
        val  btn_submit : Button  = findViewById(R.id.btn_submit)
    }

    override fun onClick(p0: View?) {

        if (p0 != null) {
            when(p0.id) {
                R.id.btn_submit -> click()
                R.id.iv_back -> onBackPressed()
            }

        }

        }


    fun click()
    {

        val name = et_name.text.toString()
        val age = Integer.parseInt(et_age.text.toString())
        val tuition : Double = et_tuition.text.toString().toDouble()
        val dates = et_date.text.toString()
     //   val date = LocalDate.parse(dates, DateTimeFormatter.ISO_DATE)


        val intent = Intent()
        intent.putExtra("name", name)
        intent.putExtra("age", age)
        intent.putExtra("tuition", tuition)
        intent.putExtra("date", dates)

        setResult(Activity.RESULT_OK,intent)
        finish()


    }
}
