package com.example.labtest1.db

import androidx.room.*

@Dao
interface StudentDao {
    @Query("SELECT * from detail ORDER BY id DESC")
    fun getAllDetail(): List<StudentEntity>?

    @Insert
    fun insertData(studentEntity: StudentEntity?)

    @Delete
    fun deleteData(studentEntity: StudentEntity?)
    @Update
    fun updateData(studentEntity: StudentEntity?)
}