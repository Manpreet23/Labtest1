package com.example.labtest1.Adapter

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.labtest1.R
import com.example.labtest1.db.StudentEntity
import kotlinx.android.synthetic.main.item_layout.view.*

class DetailAdapter(val listener: LongClickListener) : RecyclerView.Adapter<DetailAdapter.MyViewHolder>(){

    var students = ArrayList<StudentEntity>()

    fun setStudentData(data : ArrayList<StudentEntity>)
    {
        this.students = data
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DetailAdapter.MyViewHolder {

      val inflater =  LayoutInflater.from(parent.context).inflate(R.layout.item_layout,parent,false)
        return MyViewHolder(inflater,listener)
    }

    override fun getItemCount(): Int {
        Log.d("hello","s"+students.size)
        return students.size
    }

    override fun onBindViewHolder(holder: DetailAdapter.MyViewHolder, position: Int) {

        holder.itemView.setOnClickListener{
            listener.OnitemClickListner(students[position])
        }


        holder.data(students[position])
    }

    class MyViewHolder(view : View, val listener: LongClickListener) : RecyclerView.ViewHolder(view)
    {
        val tv_name = view.tv_name
        val tv_age = view.tv_age
        val tv_tuition = view.tv_tuition
        val tv_date = view.tv_date
        val ll_remove = view.ll_remove


        fun data(data: StudentEntity )
        {
            tv_name.setText("Name : "+data.name)
            tv_age.setText("Age : "+data.age)
            tv_tuition.setText("Tuition : "+data.tuition)
            tv_date.setText("Date : "+data.date)

            ll_remove.setOnLongClickListener{
                listener.onDelete(data)
                return@setOnLongClickListener true
            }



        }
    }

    interface  LongClickListener
    {
        fun onDelete(studentEntity: StudentEntity)
        fun OnitemClickListner(studentEntity: StudentEntity)
    }
}