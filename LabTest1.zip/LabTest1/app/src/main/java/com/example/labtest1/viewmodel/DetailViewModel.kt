package com.example.labtest1.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import com.example.labtest1.db.RoomAppDB
import com.example.labtest1.db.StudentEntity

class DetailViewModel(app: Application) : AndroidViewModel(app) {
    lateinit var allStudents : MutableLiveData<List<StudentEntity>>
    init {

        allStudents = MutableLiveData()
    }
    fun getAllStudentsObservers(): MutableLiveData<List<StudentEntity>>
    {
        return allStudents
    }

    fun getAllData()
    {
       val studentDao = RoomAppDB.getAppDatabase(getApplication())?.studentDao()
       val listStudents = studentDao?.getAllDetail()
        allStudents.postValue(listStudents)
    }

    fun insertStudentInfo(studentEntity: StudentEntity)
    {
       val studentDao = RoomAppDB.getAppDatabase(getApplication())?.studentDao()
        studentDao?.insertData(studentEntity)
        getAllData()
    }
    fun updateStudentInfo(studentEntity: StudentEntity)
    {
        val studentDao = RoomAppDB.getAppDatabase(getApplication())?.studentDao()
        studentDao?.updateData(studentEntity)
        getAllData()
    }

    fun deleteStudentInfo(studentEntity: StudentEntity)
    {
        val studentDao = RoomAppDB.getAppDatabase(getApplication())?.studentDao()
        studentDao?.deleteData(studentEntity)
        getAllData()
    }
}