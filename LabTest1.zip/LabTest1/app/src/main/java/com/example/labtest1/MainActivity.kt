package com.example.labtest1

import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.StaggeredGridLayoutManager.VERTICAL
import com.example.labtest1.Adapter.DetailAdapter
import com.example.labtest1.db.StudentEntity
import com.example.labtest1.viewmodel.DetailViewModel
import kotlinx.android.synthetic.main.activity_main.*
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.*
import kotlin.collections.ArrayList

class MainActivity : AppCompatActivity(), View.OnClickListener, DetailAdapter.LongClickListener {

     var id: Int = 0
    lateinit var detailadapter : DetailAdapter
    lateinit var viewModel: DetailViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
       supportActionBar?.hide()
        setContentView(R.layout.activity_main)

        initViews()


        rv_detail.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            detailadapter = DetailAdapter(this@MainActivity)
            adapter = detailadapter
        }

        val dividerItemDecoration = DividerItemDecoration(
            rv_detail.getContext(),
            VERTICAL
        )
        rv_detail.addItemDecoration(dividerItemDecoration)

        viewModel = ViewModelProviders.of(this).get(DetailViewModel::class.java)
        viewModel.getAllData()
        viewModel.getAllStudentsObservers().observe(this, Observer {
            detailadapter.setStudentData(ArrayList(it))
            detailadapter.notifyDataSetChanged()
        })
        iv_add.setOnClickListener(this)
    }

    private fun initViews() {
        val rv_detail: RecyclerView = findViewById(R.id.rv_detail)
        val iv_add : ImageView = findViewById(R.id.iv_add);

    }

    override fun onClick(p0: View?) {
    val intent = Intent(this, EditPage::class.java)
    startActivityForResult(intent,1)


    }

    override fun onDelete(studentEntity: StudentEntity) {

        viewModel.deleteStudentInfo(studentEntity)
    }

    override fun OnitemClickListner(studentEntity: StudentEntity) {
     val intent = Intent(this, EditPage::class.java)
        id = studentEntity.id
        intent.putExtra("name", studentEntity.name)
        intent.putExtra("age", studentEntity.age)
        intent.putExtra("tuition", studentEntity.tuition)
        intent.putExtra("date", studentEntity.date)
        startActivityForResult(intent,2)

    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == 1 && resultCode == Activity.RESULT_OK  && data!=null)
        {
             val name = data?.getStringExtra("name")
            val age = data?.getIntExtra("age",0)
            val tuition = data?.getDoubleExtra("tuition",0.0)
            val date = data?.getStringExtra("date")

            val student =  StudentEntity(0, name, age,tuition,date)
            viewModel.insertStudentInfo(student)
        }
        else  if (requestCode == 2 && resultCode == Activity.RESULT_OK  && data!=null)
        {
         val name = data?.getStringExtra("name")
         val age = data?.getIntExtra("age",0)
         val tuition = data?.getDoubleExtra("tuition",0.0)
          val date = data?.getStringExtra("date")

            val student =  StudentEntity(id, name, age,tuition,date)
           viewModel.updateStudentInfo(student)

        }
    }
}